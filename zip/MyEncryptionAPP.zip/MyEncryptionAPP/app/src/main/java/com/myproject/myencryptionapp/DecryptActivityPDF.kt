package com.myproject.myencryptionapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DecryptActivityPDF : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_decrypt_pdf)
    }
}