package com.myproject.myencryptionapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class EncryptActivityPDF : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_encrypt_pdf)
    }
}